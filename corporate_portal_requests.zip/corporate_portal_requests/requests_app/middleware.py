import logging
import time
import uuid
from django.conf import settings
from django.contrib.auth import login
from django.contrib.auth.models import User
from django.core.cache import cache
from django.http import HttpResponseForbidden, JsonResponse
from django.utils import timezone
from .models import AuditLog, UserProfile, UserSettings

logger = logging.getLogger(__name__)

class RequestIdMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
    def __call__(self, request):
        request.request_id = request.headers.get('X-Request-ID') or str(uuid.uuid4())
        response = self.get_response(request)
        response['X-Request-ID'] = request.request_id
        logger.info('request_id=%s %s %s -> %s', request.request_id, request.method, request.path, response.status_code)
        return response

class AuditMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
    def __call__(self, request):
        response = self.get_response(request)
        if not request.path.startswith('/admin/jsi18n/'):
            ip = request.META.get('HTTP_X_FORWARDED_FOR', request.META.get('REMOTE_ADDR', '')).split(',')[0]
            result = 'success' if response.status_code < 400 else 'error'
            try:
                AuditLog.objects.create(
                    request_id=getattr(request, 'request_id', ''),
                    user=request.user if getattr(request, 'user', None) and request.user.is_authenticated else None,
                    ip_address=ip or None,
                    user_agent=request.META.get('HTTP_USER_AGENT', ''),
                    method=request.method,
                    path=request.path,
                    status_code=response.status_code,
                    result=result,
                )
            except Exception as exc:
                logger.warning('AuditLog error: %s', exc)
        return response

class RateLimitMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
    def __call__(self, request):
        limits = getattr(settings, 'RATE_LIMITS', {})
        for prefix, rule in limits.items():
            if request.path.startswith(prefix):
                user_part = request.user.pk if getattr(request, 'user', None) and request.user.is_authenticated else request.META.get('REMOTE_ADDR', 'anon')
                cache_key = f'rate:{prefix}:{user_part}'
                data = cache.get(cache_key, {'count': 0, 'started': time.time()})
                elapsed = time.time() - data['started']
                if elapsed > rule['seconds']:
                    data = {'count': 0, 'started': time.time()}
                data['count'] += 1
                cache.set(cache_key, data, timeout=rule['seconds'])
                if data['count'] > rule['limit']:
                    return JsonResponse({'detail': 'Слишком много запросов. Повторите позже.'}, status=429)
        return self.get_response(request)

class AutoUserMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
    def __call__(self, request):
        # Для лабораторной: в DEBUG можно передать X-Auto-User: username и автоматически войти.
        # В обычной работе пользователь определяется стандартной сессией Django.
        username = request.headers.get('X-Auto-User')
        if settings.DEBUG and username and not request.user.is_authenticated:
            user, _ = User.objects.get_or_create(username=username, defaults={'email': f'{username}@local.test'})
            login(request, user)
        if request.user.is_authenticated:
            UserProfile.objects.get_or_create(user=request.user)
            UserSettings.objects.get_or_create(user=request.user)
            request.portal_role = request.user.profile.role
        else:
            request.portal_role = 'anonymous'
        return self.get_response(request)

class WorkingHoursMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
    def __call__(self, request):
        dangerous = request.method in {'POST', 'PUT', 'PATCH', 'DELETE'}
        start = getattr(settings, 'PORTAL_WORK_START_HOUR', 9)
        end = getattr(settings, 'PORTAL_WORK_END_HOUR', 18)
        hour = timezone.localtime().hour
        is_admin = getattr(request, 'portal_role', None) == 'admin' or (getattr(request, 'user', None) and request.user.is_superuser)
        allowed_paths = ['/login/', '/logout/', '/admin/']
        if dangerous and not is_admin and not (start <= hour < end) and not any(request.path.startswith(p) for p in allowed_paths):
            return HttpResponseForbidden('Опасные операции вне рабочего времени доступны только администраторам.')
        return self.get_response(request)
