from django.utils import timezone
from rest_framework.permissions import BasePermission
from .models import Ticket

def role_of(user):
    if not user.is_authenticated:
        return 'anonymous'
    if user.is_superuser:
        return 'admin'
    return getattr(getattr(user, 'profile', None), 'role', 'user')

def can_view_ticket(user, ticket):
    role = role_of(user)
    return role in ['moderator', 'admin'] or ticket.owner_id == user.id or ticket.assigned_to_id == user.id

def can_edit_ticket(user, ticket):
    role = role_of(user)
    if role == 'admin':
        return True
    if role == 'moderator':
        return ticket.status not in [Ticket.STATUS_CLOSED]
    if ticket.owner_id == user.id:
        time_ok = ticket.updated_at >= timezone.now() - timezone.timedelta(hours=24)
        return ticket.status in [Ticket.STATUS_NEW, Ticket.STATUS_REJECTED] and time_ok
    return False

class TicketObjectPermission(BasePermission):
    def has_object_permission(self, request, view, obj):
        if request.method in ['GET', 'HEAD', 'OPTIONS']:
            return can_view_ticket(request.user, obj)
        return can_edit_ticket(request.user, obj)
