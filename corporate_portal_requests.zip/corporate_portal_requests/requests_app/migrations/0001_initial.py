# Generated manually for laboratory project
from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):
    initial = True
    dependencies = [migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations = [
        migrations.CreateModel(
            name='UserProfile',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('role', models.CharField(choices=[('user', 'Обычный пользователь'), ('moderator', 'Модератор'), ('admin', 'Администратор')], default='user', max_length=20)),
                ('department', models.CharField(blank=True, max_length=120, verbose_name='Отдел')),
                ('user', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name='profile', to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='UserSettings',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('email_notifications', models.BooleanField(default=True, verbose_name='Email-уведомления')),
                ('items_per_page', models.PositiveIntegerField(default=10, verbose_name='Заявок на странице')),
                ('theme', models.CharField(default='light', max_length=20, verbose_name='Тема интерфейса')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('user', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name='portal_settings', to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='Ticket',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('title', models.CharField(max_length=200, verbose_name='Тема')),
                ('description', models.TextField(verbose_name='Описание')),
                ('service_type', models.CharField(choices=[('it', 'IT-поддержка'), ('hr', 'HR'), ('office', 'Офис'), ('security', 'Безопасность')], max_length=30, verbose_name='Сервис')),
                ('priority', models.CharField(choices=[('low', 'Низкий'), ('normal', 'Обычный'), ('high', 'Высокий'), ('critical', 'Критический')], default='normal', max_length=20, verbose_name='Приоритет')),
                ('status', models.CharField(choices=[('new', 'Новая'), ('in_progress', 'В работе'), ('approved', 'Одобрена'), ('rejected', 'Отклонена'), ('closed', 'Закрыта')], default='new', max_length=30, verbose_name='Статус')),
                ('attachment', models.FileField(blank=True, null=True, upload_to='attachments/%Y/%m/%d/', verbose_name='Файл')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('assigned_to', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='assigned_tickets', to=settings.AUTH_USER_MODEL, verbose_name='Ответственный')),
                ('owner', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='tickets', to=settings.AUTH_USER_MODEL, verbose_name='Автор')),
            ],
            options={'verbose_name': 'Заявка', 'verbose_name_plural': 'Заявки', 'ordering': ['-updated_at']},
        ),
        migrations.CreateModel(
            name='Comment',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('text', models.TextField(verbose_name='Комментарий')),
                ('is_internal', models.BooleanField(default=False, verbose_name='Внутренний комментарий')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('author', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='comments', to=settings.AUTH_USER_MODEL)),
                ('ticket', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='comments', to='requests_app.ticket')),
            ],
            options={'verbose_name': 'Комментарий', 'verbose_name_plural': 'Комментарии', 'ordering': ['created_at']},
        ),
        migrations.CreateModel(
            name='ChangeHistory',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('field_name', models.CharField(max_length=80)),
                ('old_value', models.TextField(blank=True)),
                ('new_value', models.TextField(blank=True)),
                ('changed_at', models.DateTimeField(auto_now_add=True)),
                ('ticket', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='history', to='requests_app.ticket')),
                ('user', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to=settings.AUTH_USER_MODEL)),
            ],
            options={'verbose_name': 'История изменения', 'verbose_name_plural': 'История изменений', 'ordering': ['-changed_at']},
        ),
        migrations.CreateModel(
            name='AuditLog',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('request_id', models.CharField(db_index=True, max_length=64)),
                ('ip_address', models.GenericIPAddressField(blank=True, null=True)),
                ('user_agent', models.TextField(blank=True)),
                ('method', models.CharField(max_length=10)),
                ('path', models.CharField(max_length=500)),
                ('status_code', models.PositiveIntegerField(blank=True, null=True)),
                ('result', models.CharField(blank=True, max_length=120)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('user', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to=settings.AUTH_USER_MODEL)),
            ],
            options={'verbose_name': 'Audit log', 'verbose_name_plural': 'Audit logs', 'ordering': ['-created_at']},
        ),
    ]
