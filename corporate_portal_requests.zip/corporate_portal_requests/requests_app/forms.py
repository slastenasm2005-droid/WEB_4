from django import forms
from .models import Ticket, Comment

class TicketForm(forms.ModelForm):
    class Meta:
        model = Ticket
        fields = ['title', 'description', 'service_type', 'priority', 'status', 'assigned_to', 'attachment']
        widgets = {'description': forms.Textarea(attrs={'rows': 5})}

    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        role = getattr(getattr(user, 'profile', None), 'role', 'user')
        if role == 'user' and not getattr(user, 'is_superuser', False):
            self.fields.pop('assigned_to', None)
            self.fields.pop('status', None)

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['text', 'is_internal']
        widgets = {'text': forms.Textarea(attrs={'rows': 3})}
    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        role = getattr(getattr(user, 'profile', None), 'role', 'user')
        if role == 'user' and not getattr(user, 'is_superuser', False):
            self.fields.pop('is_internal', None)
