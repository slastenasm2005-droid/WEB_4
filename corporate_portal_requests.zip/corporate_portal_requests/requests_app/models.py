from django.conf import settings
from django.contrib.auth.models import User
from django.db import models
from django.urls import reverse
from django.utils import timezone

class UserProfile(models.Model):
    ROLE_USER = 'user'
    ROLE_MODERATOR = 'moderator'
    ROLE_ADMIN = 'admin'
    ROLE_CHOICES = [
        (ROLE_USER, 'Обычный пользователь'),
        (ROLE_MODERATOR, 'Модератор'),
        (ROLE_ADMIN, 'Администратор'),
    ]
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default=ROLE_USER)
    department = models.CharField(max_length=120, blank=True, verbose_name='Отдел')

    def __str__(self):
        return f'{self.user.username} — {self.get_role_display()}'

class UserSettings(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='portal_settings')
    email_notifications = models.BooleanField(default=True, verbose_name='Email-уведомления')
    items_per_page = models.PositiveIntegerField(default=10, verbose_name='Заявок на странице')
    theme = models.CharField(max_length=20, default='light', verbose_name='Тема интерфейса')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'Настройки {self.user.username}'

class Ticket(models.Model):
    STATUS_NEW = 'new'
    STATUS_IN_PROGRESS = 'in_progress'
    STATUS_APPROVED = 'approved'
    STATUS_REJECTED = 'rejected'
    STATUS_CLOSED = 'closed'
    STATUS_CHOICES = [
        (STATUS_NEW, 'Новая'),
        (STATUS_IN_PROGRESS, 'В работе'),
        (STATUS_APPROVED, 'Одобрена'),
        (STATUS_REJECTED, 'Отклонена'),
        (STATUS_CLOSED, 'Закрыта'),
    ]
    SERVICE_CHOICES = [
        ('it', 'IT-поддержка'),
        ('hr', 'HR'),
        ('office', 'Офис'),
        ('security', 'Безопасность'),
    ]
    PRIORITY_CHOICES = [('low', 'Низкий'), ('normal', 'Обычный'), ('high', 'Высокий'), ('critical', 'Критический')]

    title = models.CharField(max_length=200, verbose_name='Тема')
    description = models.TextField(verbose_name='Описание')
    service_type = models.CharField(max_length=30, choices=SERVICE_CHOICES, verbose_name='Сервис')
    priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES, default='normal', verbose_name='Приоритет')
    status = models.CharField(max_length=30, choices=STATUS_CHOICES, default=STATUS_NEW, verbose_name='Статус')
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name='tickets', verbose_name='Автор')
    assigned_to = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='assigned_tickets', verbose_name='Ответственный')
    attachment = models.FileField(upload_to='attachments/%Y/%m/%d/', blank=True, null=True, verbose_name='Файл')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-updated_at']
        verbose_name = 'Заявка'
        verbose_name_plural = 'Заявки'

    def __str__(self):
        return f'#{self.pk} {self.title}'

    def get_absolute_url(self):
        return reverse('ticket_detail', args=[self.pk])

    def changed_recently(self, hours=24):
        return self.updated_at >= timezone.now() - timezone.timedelta(hours=hours)

class Comment(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name='comments')
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='comments')
    text = models.TextField(verbose_name='Комментарий')
    is_internal = models.BooleanField(default=False, verbose_name='Внутренний комментарий')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']
        verbose_name = 'Комментарий'
        verbose_name_plural = 'Комментарии'

    def __str__(self):
        return f'Комментарий {self.author} к заявке {self.ticket_id}'

class ChangeHistory(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name='history')
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    field_name = models.CharField(max_length=80)
    old_value = models.TextField(blank=True)
    new_value = models.TextField(blank=True)
    changed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-changed_at']
        verbose_name = 'История изменения'
        verbose_name_plural = 'История изменений'

class AuditLog(models.Model):
    request_id = models.CharField(max_length=64, db_index=True)
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(blank=True)
    method = models.CharField(max_length=10)
    path = models.CharField(max_length=500)
    status_code = models.PositiveIntegerField(null=True, blank=True)
    result = models.CharField(max_length=120, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Audit log'
        verbose_name_plural = 'Audit logs'
