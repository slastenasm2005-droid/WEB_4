from django.contrib.auth.models import User
from django.core.management.base import BaseCommand
from requests_app.models import Ticket, UserProfile

class Command(BaseCommand):
    help = 'Создает демо-пользователей и заявки для проверки лабораторной'
    def handle(self, *args, **options):
        admin, _ = User.objects.get_or_create(username='admin', defaults={'is_staff': True, 'is_superuser': True, 'email': 'admin@test.local'})
        admin.set_password('admin12345'); admin.save()
        moderator, _ = User.objects.get_or_create(username='moderator', defaults={'email': 'moderator@test.local'})
        moderator.set_password('moderator12345'); moderator.save()
        user, _ = User.objects.get_or_create(username='user', defaults={'email': 'user@test.local'})
        user.set_password('user12345'); user.save()
        admin.profile.role = UserProfile.ROLE_ADMIN; admin.profile.save()
        moderator.profile.role = UserProfile.ROLE_MODERATOR; moderator.profile.save()
        user.profile.role = UserProfile.ROLE_USER; user.profile.save()
        Ticket.objects.get_or_create(title='Настроить доступ к корпоративной почте', owner=user, defaults={'description':'Не получается войти в почту.', 'service_type':'it', 'priority':'high', 'assigned_to':moderator})
        Ticket.objects.get_or_create(title='Заказать пропуск для гостя', owner=user, defaults={'description':'Нужен временный пропуск.', 'service_type':'security', 'priority':'normal'})
        self.stdout.write(self.style.SUCCESS('Демо-данные созданы. Логины: admin/admin12345, moderator/moderator12345, user/user12345'))
