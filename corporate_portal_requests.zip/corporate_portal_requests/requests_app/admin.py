from django.contrib import admin
from .models import AuditLog, ChangeHistory, Comment, Ticket, UserProfile, UserSettings

class CommentInline(admin.TabularInline):
    model = Comment
    extra = 0

class ChangeHistoryInline(admin.TabularInline):
    model = ChangeHistory
    extra = 0
    readonly_fields = ['user', 'field_name', 'old_value', 'new_value', 'changed_at']
    can_delete = False

@admin.register(Ticket)
class TicketAdmin(admin.ModelAdmin):
    list_display = ['id', 'title', 'service_type', 'priority', 'status', 'owner', 'assigned_to', 'updated_at']
    list_filter = ['status', 'service_type', 'priority', 'created_at']
    search_fields = ['title', 'description', 'owner__username']
    date_hierarchy = 'created_at'
    inlines = [CommentInline, ChangeHistoryInline]

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'role', 'department']
    list_filter = ['role']
    search_fields = ['user__username', 'department']

@admin.register(UserSettings)
class UserSettingsAdmin(admin.ModelAdmin):
    list_display = ['user', 'email_notifications', 'items_per_page', 'theme', 'updated_at']

@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ['ticket', 'author', 'is_internal', 'created_at']
    list_filter = ['is_internal', 'created_at']

@admin.register(ChangeHistory)
class ChangeHistoryAdmin(admin.ModelAdmin):
    list_display = ['ticket', 'user', 'field_name', 'changed_at']
    list_filter = ['field_name', 'changed_at']

@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display = ['created_at', 'request_id', 'user', 'method', 'path', 'status_code', 'result']
    list_filter = ['method', 'status_code', 'result', 'created_at']
    search_fields = ['request_id', 'path', 'user_agent']
    readonly_fields = ['request_id', 'user', 'ip_address', 'user_agent', 'method', 'path', 'status_code', 'result', 'created_at']
