from rest_framework import serializers, viewsets
from .models import AuditLog, Comment, Ticket, UserSettings
from .permissions import TicketObjectPermission, can_view_ticket, role_of

class TicketSerializer(serializers.ModelSerializer):
    owner_username = serializers.CharField(source='owner.username', read_only=True)
    class Meta:
        model = Ticket
        fields = ['id', 'title', 'description', 'service_type', 'priority', 'status', 'owner', 'owner_username', 'assigned_to', 'attachment', 'created_at', 'updated_at']
        read_only_fields = ['owner', 'created_at', 'updated_at']

class CommentSerializer(serializers.ModelSerializer):
    author_username = serializers.CharField(source='author.username', read_only=True)
    class Meta:
        model = Comment
        fields = ['id', 'ticket', 'author', 'author_username', 'text', 'is_internal', 'created_at']
        read_only_fields = ['author', 'created_at']

class UserSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserSettings
        fields = ['id', 'user', 'email_notifications', 'items_per_page', 'theme', 'created_at', 'updated_at']
        read_only_fields = ['user', 'created_at', 'updated_at']

class AuditLogSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username', read_only=True)
    class Meta:
        model = AuditLog
        fields = ['id', 'request_id', 'user', 'username', 'ip_address', 'user_agent', 'method', 'path', 'status_code', 'result', 'created_at']
        read_only_fields = fields

class TicketViewSet(viewsets.ModelViewSet):
    serializer_class = TicketSerializer
    permission_classes = [TicketObjectPermission]
    filterset_fields = ['status', 'service_type', 'priority', 'owner', 'assigned_to']
    search_fields = ['title', 'description']
    ordering_fields = ['created_at', 'updated_at', 'priority']
    def get_queryset(self):
        qs = Ticket.objects.select_related('owner', 'assigned_to')
        role = role_of(self.request.user)
        if role in ['moderator', 'admin']:
            return qs
        return qs.filter(owner=self.request.user) | qs.filter(assigned_to=self.request.user)
    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)

class CommentViewSet(viewsets.ModelViewSet):
    serializer_class = CommentSerializer
    filterset_fields = ['ticket', 'author', 'is_internal']
    def get_queryset(self):
        qs = Comment.objects.select_related('ticket', 'author')
        role = role_of(self.request.user)
        if role in ['moderator', 'admin']:
            return qs
        return qs.filter(ticket__owner=self.request.user, is_internal=False)
    def perform_create(self, serializer):
        ticket = serializer.validated_data['ticket']
        if not can_view_ticket(self.request.user, ticket):
            from rest_framework.exceptions import PermissionDenied
            raise PermissionDenied('Нет доступа к этой заявке')
        serializer.save(author=self.request.user)

class UserSettingsViewSet(viewsets.ModelViewSet):
    serializer_class = UserSettingsSerializer
    def get_queryset(self):
        return UserSettings.objects.filter(user=self.request.user)
    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class AuditLogViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = AuditLogSerializer
    filterset_fields = ['method', 'status_code', 'result', 'user']
    search_fields = ['path', 'request_id', 'user_agent']
    def get_queryset(self):
        if role_of(self.request.user) == 'admin':
            return AuditLog.objects.select_related('user')
        return AuditLog.objects.none()
