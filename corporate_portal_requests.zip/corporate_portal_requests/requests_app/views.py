from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from .forms import CommentForm, TicketForm
from .models import ChangeHistory, Ticket
from .permissions import can_edit_ticket, can_view_ticket, role_of

@login_required
def ticket_list(request):
    tickets = Ticket.objects.select_related('owner', 'assigned_to')
    role = role_of(request.user)
    if role == 'user':
        tickets = tickets.filter(Q(owner=request.user) | Q(assigned_to=request.user))
    status = request.GET.get('status')
    service = request.GET.get('service_type')
    priority = request.GET.get('priority')
    query = request.GET.get('q')
    if status:
        tickets = tickets.filter(status=status)
    if service:
        tickets = tickets.filter(service_type=service)
    if priority:
        tickets = tickets.filter(priority=priority)
    if query:
        tickets = tickets.filter(Q(title__icontains=query) | Q(description__icontains=query))
    return render(request, 'requests_app/ticket_list.html', {
        'tickets': tickets,
        'status_choices': Ticket.STATUS_CHOICES,
        'service_choices': Ticket.SERVICE_CHOICES,
        'priority_choices': Ticket.PRIORITY_CHOICES,
        'role': role,
    })

@login_required
def ticket_detail(request, pk):
    ticket = get_object_or_404(Ticket.objects.select_related('owner', 'assigned_to'), pk=pk)
    if not can_view_ticket(request.user, ticket):
        raise PermissionDenied
    comments = ticket.comments.select_related('author')
    if role_of(request.user) == 'user':
        comments = comments.filter(is_internal=False)
    form = CommentForm(request.POST or None, user=request.user)
    if request.method == 'POST' and form.is_valid():
        comment = form.save(commit=False)
        comment.ticket = ticket
        comment.author = request.user
        comment.save()
        messages.success(request, 'Комментарий добавлен.')
        return redirect(ticket)
    return render(request, 'requests_app/ticket_detail.html', {'ticket': ticket, 'comments': comments, 'form': form, 'can_edit': can_edit_ticket(request.user, ticket)})

@login_required
def ticket_create(request):
    form = TicketForm(request.POST or None, request.FILES or None, user=request.user)
    if request.method == 'POST' and form.is_valid():
        ticket = form.save(commit=False)
        ticket.owner = request.user
        if role_of(request.user) == 'user':
            ticket.status = Ticket.STATUS_NEW
        ticket.save()
        ChangeHistory.objects.create(ticket=ticket, user=request.user, field_name='created', old_value='', new_value=ticket.status)
        messages.success(request, 'Заявка создана.')
        return redirect(ticket)
    return render(request, 'requests_app/ticket_form.html', {'form': form, 'title': 'Создание заявки'})

@login_required
def ticket_edit(request, pk):
    ticket = get_object_or_404(Ticket, pk=pk)
    if not can_edit_ticket(request.user, ticket):
        raise PermissionDenied
    old = {field: getattr(ticket, field) for field in ['title', 'description', 'service_type', 'priority', 'status', 'assigned_to_id']}
    form = TicketForm(request.POST or None, request.FILES or None, instance=ticket, user=request.user)
    if request.method == 'POST' and form.is_valid():
        ticket = form.save()
        for field, old_value in old.items():
            new_value = getattr(ticket, field)
            if str(old_value) != str(new_value):
                ChangeHistory.objects.create(ticket=ticket, user=request.user, field_name=field, old_value=str(old_value), new_value=str(new_value))
        messages.success(request, 'Заявка обновлена.')
        return redirect(ticket)
    return render(request, 'requests_app/ticket_form.html', {'form': form, 'title': 'Редактирование заявки'})

@login_required
def moderator_panel(request):
    if role_of(request.user) not in ['moderator', 'admin']:
        raise PermissionDenied
    tickets = Ticket.objects.exclude(status=Ticket.STATUS_CLOSED).select_related('owner', 'assigned_to')
    return render(request, 'requests_app/moderator_panel.html', {'tickets': tickets})
