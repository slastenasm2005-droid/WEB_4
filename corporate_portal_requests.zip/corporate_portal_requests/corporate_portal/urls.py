from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import include, path
from rest_framework.routers import DefaultRouter
from requests_app.api import TicketViewSet, CommentViewSet, AuditLogViewSet, UserSettingsViewSet

router = DefaultRouter()
router.register('tickets', TicketViewSet, basename='api-tickets')
router.register('comments', CommentViewSet, basename='api-comments')
router.register('audit-logs', AuditLogViewSet, basename='api-audit-logs')
router.register('settings', UserSettingsViewSet, basename='api-settings')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('requests_app.urls')),
    path('api/', include(router.urls)),
    path('login/', auth_views.LoginView.as_view(template_name='requests_app/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
